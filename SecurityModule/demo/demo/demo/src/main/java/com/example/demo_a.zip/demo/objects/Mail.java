package com.example.demo.objects;

public class Mail {
    private String mail;
    public String getMail() {
        return mail;
    }

    public Mail(String mail){
        this.mail = mail;
    }

    public Mail() {
    }
}
